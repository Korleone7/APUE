#include <stdio.h>

int main(void)
{
    while(1);

    return 0;
}
